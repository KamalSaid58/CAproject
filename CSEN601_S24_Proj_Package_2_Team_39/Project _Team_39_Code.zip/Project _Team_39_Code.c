#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>

short unsigned int pc = 0;
short int instructionMem[1024];
int8_t dataMem[2048];
int8_t generalRegisters[64];
int8_t SREG; // status register
typedef struct instruction
{
    short int fullInstruction;
    int8_t opcode;
    int8_t r1Address;
    int8_t r2Address;
    int8_t imm;
    int isEnabled;
} instruction;
int isBranched;
void ALU(instruction *instructionPTR);

// parse txt file
uint8_t parseOperand(char *operand) // if an overflow occurs ie the number is greater than 6 bits then 0 is returned
{
    unsigned int result = 0;
    if (strchr(operand, 'R') != NULL)     // in other words, it is a register
        sscanf(++operand, "%i", &result); // get the number(s) next to the R and turn it into an int
    else
        sscanf(operand, "%i", &result);

    result = result & 0b00111111;
    return result;
}
uint16_t parseOPcode(char *opcode)
{
    if (strcmp(opcode, "ADD") == 0)
        return 0;
    else if (strcmp(opcode, "SUB") == 0)
        return 1;
    else if (strcmp(opcode, "MUL") == 0)
        return 2;
    else if (strcmp(opcode, "LDI") == 0)
        return 3;
    else if (strcmp(opcode, "BEQZ") == 0)
        return 4;
    else if (strcmp(opcode, "AND") == 0)
        return 5;
    else if (strcmp(opcode, "OR") == 0)
        return 6;
    else if (strcmp(opcode, "JR") == 0)
        return 7;
    else if (strcmp(opcode, "SLC") == 0)
        return 8;
    else if (strcmp(opcode, "SRC") == 0)
        return 9;
    else if (strcmp(opcode, "LB") == 0)
        return 10;
    else if (strcmp(opcode, "SB") == 0)
        return 11;
}
void parse(char *filePath)
{
    FILE *assemblyCode = fopen(filePath, "r"); // "r" means read file
    const unsigned MAX_LENGTH = 256;           // maximum number of characters to be read in a single line; mazonsh haykoon akbar mein keda ya3ni
    char strInstruction[MAX_LENGTH];           // where the string will be stored
    int memoryLocation = 0;
    while (fgets(strInstruction, MAX_LENGTH, assemblyCode)) // fgets returns null once end of file is reaches which breaks the loop
    {
        char *ptrInstruction = strInstruction; // pointer to the array so i can use it to dereference later in methods
        char *currentString;                   // used to store what part of string I have split so far

        currentString = strtok_r(ptrInstruction, " ", &ptrInstruction); // points to string up until the first " " it finds
        int16_t opcode = parseOPcode(currentString) << 12;

        currentString = strtok_r(ptrInstruction, " ", &ptrInstruction);
        int16_t firstOperand = parseOperand(currentString) << 6;

        currentString = strtok_r(ptrInstruction, " ", &ptrInstruction);
        uint8_t secondOperand = parseOperand(currentString); // the reason this is 8 bits is because 1) we do not shift it and 2) if the number turns out negative,
                                                             // we have to remove the first 2 bits and flip them into 0s so that they fit inside the memory

        int16_t instruction = opcode | firstOperand | secondOperand;
        instructionMem[memoryLocation] = instruction;
        memoryLocation++;
    }
    instructionMem[memoryLocation] = __SHRT_MAX__;
    fclose(assemblyCode);
}

void InstFetch(instruction *instructionPTR)
{
    instructionPTR->fullInstruction = instructionMem[pc++]; // -> dereferences the pointer, get the variable, and stories the instruction into it
    if (instructionPTR->fullInstruction == __SHRT_MAX__)
        instructionPTR->isEnabled = 0;
    else
        printf("Fetched instruction: %b\n", instructionPTR->fullInstruction);
}

void InstDecode(instruction *instructionPTR)
{ // Decode or break the instruction using I or R format
    short int inst = instructionPTR->fullInstruction;
    instructionPTR->opcode = (inst >> 12) & 0b1111;
    instructionPTR->r1Address = (inst >> 6) & 0b111111;
    instructionPTR->r2Address = (inst & 0b111111);
    instructionPTR->imm = (inst & 0b111111);
    printf("Decoding instruction: %b\n", inst);
    printf("Opcode: %b\n", instructionPTR->opcode);
    printf("R1: %d\n", instructionPTR->r1Address);
    printf("R2: %d\n", instructionPTR->r2Address);
    printf("Value[R1]: %d\n", generalRegisters[instructionPTR->r1Address]);
    printf("Value[R2]: %d\n", generalRegisters[instructionPTR->r2Address]);
    printf("Immediate: %d\n", instructionPTR->imm);
}

void InstExecute(instruction *instructionPTR)
{
    ALU(instructionPTR);
}

void ALU(instruction *instructionPTR)
{ // temp because of I fromat instructions
    printf("Executing instruction: %b\n", instructionPTR->fullInstruction);
    int8_t opcode = instructionPTR->opcode;
    int8_t firstOperand = generalRegisters[instructionPTR->r1Address];
    int8_t secondOperand;
    if (opcode == 0 || opcode == 1 || opcode == 2 || opcode == 5 || opcode == 6 || opcode == 7)
        secondOperand = generalRegisters[instructionPTR->r2Address];
    else // the execute will be given I Format inputs check instruction table
        secondOperand = instructionPTR->imm;

    int C, V, N, S, Z; // the flags but separate
    C = V = N = S = Z = 0;
    int8_t result, resultLastBit;
    int8_t firstOperandLastBit, secondOperandLastBit; // last bits in a and b and result(temp)

    switch (opcode)
    {
    case 0: // Addition
    {
        result = firstOperand + secondOperand;
        short unsigned int unsignedFirstOperand = firstOperand & 0xFF;
        short unsigned int unsignedSecondOperand = secondOperand & 0xFF;
        short unsigned int unsignedResult = (unsignedFirstOperand + unsignedSecondOperand) & 0b111111111;
        if (unsignedResult >> 8 == 1)
            C = 1;

        firstOperandLastBit = (firstOperand & 0b10000000) >> 7;   // got the last bit in the first operand
        secondOperandLastBit = (secondOperand & 0b10000000) >> 7; // got the last bit in the second operand
        resultLastBit = (result & 0b10000000) >> 7;               // got the last bit in the result
        if ((firstOperandLastBit == 1 && secondOperandLastBit == 1 && resultLastBit == 0) ||
            (firstOperandLastBit == 0 && secondOperandLastBit == 0 && resultLastBit == 1))
            V = 1; // Overflow or V is 1

        printf("Addition executed: R%d + R%d = %d\n",
               instructionPTR->r1Address, instructionPTR->r2Address, result);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);

        break;
    }
    case 1:
    { // Subtraction
        result = firstOperand - secondOperand;
        firstOperandLastBit = (firstOperand & 0b10000000) >> 7;   // got the last bit in r1
        secondOperandLastBit = (secondOperand & 0b10000000) >> 7; // got the last bit in r2
        resultLastBit = (result & 0b10000000) >> 7;               // got the last bit in r1
        if ((firstOperandLastBit == 0 && secondOperandLastBit == 1 && resultLastBit == 1) ||
            (firstOperandLastBit == 1 && secondOperandLastBit == 0 && resultLastBit == 0))
            V = 1; // Overflow or V is 1

        printf("Subtraction executed: R%d - R%d = %d\n",
               instructionPTR->r1Address, instructionPTR->r2Address, result);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);
        break;
    }
    case 2:
    { // Multiply
        result = firstOperand * secondOperand;
        generalRegisters[instructionPTR->r1Address] = result;

        printf("Multiplication executed: R%d * R%d = %d\n",
               instructionPTR->r1Address, instructionPTR->r2Address, result);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);
        break;
    }
    case 3: // Load immediate
    {
        // since our numbers are signed, if the MSB of the secondOperand is 1 (the 6th bit)
        // then we must fill the rest of the 16 bits 1s
        secondOperandLastBit = (secondOperand & 0b100000) >> 5;

        if (secondOperandLastBit == 1)
            result = secondOperand | 0b11000000;
        else
            result = secondOperand;
        printf("Load immediate executed: R%d = %d\n",
               instructionPTR->r1Address, result);
        break;
    }
    case 4:
    { // branch if equal Zero
        if (firstOperand == 0)
        {
            pc += secondOperand - 2; // since the PC has already incremented twice during fetch and decode of other instructions, we want to
            isBranched = 1;          // undo this, so we subtract 2
            printf("Branch executed: Jumping to instruction %d\n", pc);
        }
        else
            printf("Did not execute jump since R%d was not zero\n",
                   instructionPTR->r1Address);

        break;
    }
    case 5:
    { // AND gate
        result = firstOperand & secondOperand;
        printf("AND executed: R%d & R%d = %d\n",
               instructionPTR->r1Address, instructionPTR->r2Address, result);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);
        break;
    }
    case 6:
    { // OR gate
        result = firstOperand | secondOperand;
        printf("OR executed: R%d | R%d = % d\n ",
               instructionPTR->r1Address,
               instructionPTR->r2Address, result);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);

        break;
    }
    case 7:
    {                                        // Jump Register
        pc = firstOperand;                   // I made it like this because a is only 8 bits
        pc = (pc << 8) & 0b1111111100000000; // shift by 8 bits and and it to get the least sig bits to zero
        pc = pc | secondOperand;             // or it with b
        isBranched = 1;
        printf("Jump Register executed: Jumping to %d\n", pc);
        break;
    }
    case 8:
    { // Shift Left circular
        result = (firstOperand << secondOperand) | (firstOperand >> (8 - secondOperand));
        printf("Shift left circular executed: R%d was shifted %d times\n",
               instructionPTR->r1Address, secondOperand);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);

        break;
    }
    case 9:
    { // Shift Right circular
        result = (firstOperand >> secondOperand) | (firstOperand << (8 - secondOperand));
        printf("Shift right circular executed: R%d was shifted %d times\n",
               instructionPTR->r1Address, secondOperand);
        printf("R%d new value = %d\n", instructionPTR->r1Address, result);
        break;
    }
    case 10:
    {                                    // Load byte
        result = dataMem[secondOperand]; // load r1 with the data in address b
        printf("Load byte executed: Loaded R%d in DataMemory[%d]\n",
               instructionPTR->r1Address, secondOperand);
        printf("R%d new value = %d\n", instructionPTR->r1Address,
               result);
        break;
    }
    case 11:
    { // Stror r1 in address b
        dataMem[secondOperand] = generalRegisters[instructionPTR->r1Address];

        printf("Store byte executed: R%d stored in DataMemory[%d]\n",
               instructionPTR->r1Address, secondOperand);
        printf("DataMemory[%d] new value = %d\n", secondOperand,
               generalRegisters[instructionPTR->r1Address]);
        break;
    }
    default:
        perror("enter number between 0 and 11 \n");
        break;
    }

    if (opcode == 0 || opcode == 1 || opcode == 2 || opcode == 5 || opcode == 6 ||
        opcode == 8 || opcode == 9)
    {
        if (result < 0)
            N = 1;

        if (result == 0)
            Z = 1;
    }

    if (opcode == 0 || opcode == 1)
    {
        S = N ^ V; // Sign flag or s is 1
    }
    if (opcode != 4 && opcode != 7 && opcode != 11)
        generalRegisters[instructionPTR->r1Address] = result;
    SREG = (C * 16) + (V * 8) + (N * 4) + (S * 2) + Z;
    printf("Status register: %b\n", SREG);
}

// deep clones the instructions
void copyInstruction(instruction *source, instruction *destination)
{
    destination->fullInstruction = source->fullInstruction;
    destination->imm = source->imm;
    destination->opcode = source->opcode;
    destination->r1Address = source->r1Address;
    destination->r2Address = source->r2Address;
    destination->isEnabled = source->isEnabled;
}
void runProgram()
{
    int cycle = 1;
    parse("assembly.txt");
    instruction fetch, decode, execute;
    fetch.isEnabled = 1;
    decode.isEnabled = 0;
    execute.isEnabled = 0;
    isBranched = 0; // used to detect if any jumps happened
    while (1)
    {
        printf("Clock cycle: %d\n", cycle++);
        // in our implementation, whenever we reach the end of the program we define it as all 1s, or the max number we're able to fit in 16 bits
        // if it finds the max, it turns off fetch enabled flag, which will also disable decode in the next cycle and execute in the one after it
        if (fetch.isEnabled == 1)
            InstFetch(&fetch);
        if (decode.isEnabled == 1)
            InstDecode(&decode);
        if (execute.isEnabled == 1)
            InstExecute(&execute);

        // copy instruction passes the instruction from one stage to the other
        copyInstruction(&decode, &execute);
        copyInstruction(&fetch, &decode);

        if (isBranched == 1)
        {
            // disables both decode and execute preventing the instructions during the jump from executing
            // fetch will continue on and fetch the instruction after jump normally
            decode.isEnabled = 0;
            execute.isEnabled = 0;
            isBranched = 0;
        }

        if (fetch.isEnabled == 0 && decode.isEnabled == 0 && execute.isEnabled == 0)
            break;
        printf("--------------------------------------------------------------\n");
    }
}

int main()
{
    // parse("assembly.txt");
    runProgram();
}